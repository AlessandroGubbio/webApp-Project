import { OnInit } from '@angular/core';
import { Component } from '@angular/core';
import { LayoutService } from './service/app.layout.service';
import { LoginService } from '../demo/service/login.service';

@Component({
    selector: 'app-menu',
    templateUrl: './app.menu.component.html'
})
export class AppMenuComponent implements OnInit {

    model: any[] = [];

    constructor(public layoutService: LayoutService, private loginService: LoginService) { }

    ngOnInit() {
        const id = JSON.parse(localStorage.getItem('loggedUser')).idUser
        
        this.model = [
            {
                label: 'Home',
                items: [
                    { label: 'Home', icon: 'pi pi-fw pi-home', routerLink: ['/'] }
                ]
            },
            {
                label: 'News',
                items: [
                    { label: 'Novità', icon: 'pi pi-fw pi-book', routerLink: ['/extra/news'] },
                    { label: 'Pubblica', icon: 'pi pi-fw pi-plus-circle', routerLink: ['/extra/post'] },
                ]
            },
            {
                label: 'Dipendenti',
                items: [
                    { label: 'Buste Paga', icon: 'pi pi-fw pi-file-pdf', routerLink: ['/extra/cedolini'] },
                    { label: 'Calendario', icon: 'pi pi-fw pi-calendar', routerLink: ['/extra/calendario'] },
                    { label: 'Lista Presenze', icon: 'pi pi-fw pi-history', routerLink: ['/extra/lista-presenze'] }

                ]
            }
        ];
        this.loginService.checkAdmin(id).subscribe(
            {
                next: (data) => {
                    data.forEach(
                        (element) => {
                            if (element.name.includes('ADMIN') ){
                                this.model.push(
                                    {
                                        label: 'Admin',
                                        items: [
                                            { label: 'Assegna Documento', icon: 'pi pi-fw pi-file-import', routerLink: ['/extra/insert-document'] },
                                            { label: 'Management Progetti', icon: 'pi pi-fw pi-briefcase', routerLink: ['/extra/management-progetti'] },
                                            { label: 'Management Dipendenti', icon: 'pi pi-fw pi-users', routerLink: ['/extra/dipendenti'] },
                                            { label: 'Management News', icon: 'pi pi-fw pi-list', routerLink: ['/extra/news-list'] },
                                        ]
                                    }
                                )
                            }
                            
                        }
                    )
                }
            }
        )
    }
}
