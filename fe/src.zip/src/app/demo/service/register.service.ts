import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { UserDto } from "src/app/dto/user.dto";

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  constructor(private httpClient: HttpClient) {}
  apiUrl: string = 'http://192.168.222.140:8080/'

  callRegisterService(dto: any): Observable<any> {
    console.log(dto);
    return this.httpClient.post('this.apiUrl + doRegister', JSON.stringify(dto));
  }
}