import { DragDropModule } from '@angular/cdk/drag-drop';
import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { MessageService } from 'primeng/api';
import { DropdownModule } from 'primeng/dropdown';
import { TableModule } from 'primeng/table';
import { ToastModule } from 'primeng/toast';
import { PresenzeService } from 'src/app/demo/service/presenze.service';
import { Presenza } from 'src/app/dto/presenza.dto';

interface Month{
  name: string;
}

@Component({
  selector: 'app-lista-presenze',
  standalone: true,
  providers: [
    MessageService,
    PresenzeService
  ],
  imports: [
    TableModule,
    ToastModule,
    DragDropModule,
    DropdownModule,
    CommonModule
  ],
  templateUrl: './lista-presenze.component.html',
  styleUrl: './lista-presenze.component.scss'
})

export class ListaPresenzeComponent implements OnInit{
  presenza: Presenza[] = [];
  presenzaFull: Presenza[] = [];
  months: Month[];
  selectedMonth: string = "";
  searchTerm: string = "";
  presenzaCount: number = 0;

  constructor(
    private messageService: MessageService, 
    private presenzeService: PresenzeService,
    private router: Router
) {}

  ngOnInit(): void {
    this.months = [
      {name : 'gennaio' },
      {name : 'febbraio' },
      {name : 'marzo' },
      {name : 'aprile' },
      {name : 'maggio' },
      {name : 'giugno' },
      {name : 'luglio' },
      {name : 'agosto' },
      {name : 'settembre'},
      {name : 'ottobre'},
      {name : 'novembre'},
      {name : 'dicembre'}
      
  ]
    this.presenzeService.getPresenze().subscribe(
      presenza => {
        this.presenza = presenza
        this.presenzaFull = presenza,
        this.presenza.forEach((presenza) =>{
          presenza.data = new Date(presenza.data + 'T00:00:00')
        })
        this. presenza = this.presenza.filter(
          (presenza) => {
            
            const monthName = new Intl.DateTimeFormat('it-IT', { month: 'long' })
            .format(new Date(presenza.data));
            if (monthName.toLowerCase().startsWith(this.months[0].name.toLowerCase())) {
              this.presenzaCount++;
            }
            return monthName.toLowerCase().startsWith(this.months[0].name);
          }
        
        );
        if(this.presenzaCount<1){
          this.messageService.add({ severity: 'info', detail: 'Nessuna presenza trovata per questo mese!'})
        }
      },
      error => console.log(error)
    )
  }

  onMonthChange(selectedMonth : any){
    this.presenzaCount = 0;
    this.presenza = this.presenzaFull.filter(
        (presenza) => {
          const monthName = new Intl.DateTimeFormat('it-IT', { month: 'long' })
          .format(new Date(presenza.data));
          if (monthName.toLowerCase().startsWith(selectedMonth.value.name.toLowerCase())) {
            this.presenzaCount++;
          }
          return monthName.toLowerCase().startsWith(selectedMonth.value.name.toLowerCase());
        }
    );
    if(this.presenzaCount<1){
      this.messageService.add({ severity: 'info', detail: 'Nessuna presenza trovata per questo mese!'})
    }
}

  getDate(presenza: any){
    return new Intl.DateTimeFormat('it-IT', { day: 'numeric', month: 'long', year: 'numeric' }).format(presenza)
  }

  calcoloTotaleOreLavorate(): number {
    if (!this.presenza || !this.presenza.length) {
      return 0; 
    }
  
    const totalHours = this.presenza.reduce((acc, presenza) => {
      const presenzaHours = parseFloat(presenza.totale);
      return acc + presenzaHours;
    }, 0);
  
    return totalHours;
  }

  calcoloTotaleOrePermessi(): number{
    if (!this.presenza || !this.presenza.length) {
      return 0; 
    }
    const totalPermessi = this.presenza.reduce((acc, presenza) => {
      const permessiHours = parseFloat(presenza.permesso);
      return acc + permessiHours;
    }, 0);
    return totalPermessi;
  }

  calcoloTotaleOreFerie(): number{
    if (!this.presenza || !this.presenza.length) {
      return 0; 
    }
    const totalFerie = this.presenza.reduce((acc, presenza) =>{
      const ferieHours = parseFloat(presenza.ferie);
      return acc + ferieHours;
    }, 0);
    
    return totalFerie;
  }

  formatTime(timeString) {
    const [hours, minutes, seconds] = timeString.split(':');
    return `${hours}:${minutes}`;
  }
}
