import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ListaPresenzeComponent } from './lista-presenze.component';
import { ListaPresenzeRoutingModule } from './lista-presenze-routing.module';
import { DropdownModule } from 'primeng/dropdown';

@NgModule({
    imports: [
        CommonModule,
        ListaPresenzeRoutingModule,
        ListaPresenzeComponent,
        DropdownModule
    ],
    declarations: []
})
export class ListaPresenzeModule { }
